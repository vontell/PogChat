webpackHotUpdate("contentScript",{

/***/ "./src/contentScript/api.js":
/*!**********************************!*\
  !*** ./src/contentScript/api.js ***!
  \**********************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/*global chrome*/
const axios = __webpack_require__(/*! axios */ "./node_modules/axios/index.js").default;

const BASE_URL = "http://localhost:8080";

async function getHeaders() {
  return new Promise(resolve => {
    chrome.storage.sync.get("info", data => {
      resolve({
        'Authorization': 'Pogger ' + data.info.access_token
      });
    });
  });
}

const PogApi = {
  async getTopics(stream, category) {
    let headers = await getHeaders();
    let params = {
      category
    };

    if (stream) {
      params['stream'] = stream;
    }

    return axios.get(`${BASE_URL}/topics`, {
      headers: headers,
      params
    });
  },

  async getPopularTopics() {
    let headers = await getHeaders();
    return axios.get(`${BASE_URL}/topics/popular`, {
      headers: headers
    });
  },

  async getParticipatingTopics() {
    let headers = await getHeaders();
    return axios.get(`${BASE_URL}/topics/participant`, {
      headers: headers
    });
  },

  async getStartingTopics(stream, category) {
    let headers = await getHeaders();
    let url = new URL(BASE_URL);
    let params = url.searchParams;
    params.append("q", "This is seach query");
    return axios.get(`${BASE_URL}/topics/startup`, {
      headers: headers
    });
  },

  async viewTopic(topic_id) {
    let headers = await getHeaders();
    return axios.post(`${BASE_URL}/topics/view`, {
      topic_id
    }, {
      headers: headers
    });
  },

  async createTopic(title, description, category, stream) {
    let headers = await getHeaders();
    return axios.post(`${BASE_URL}/topics`, {
      "title": title,
      "category": category,
      "description": description,
      "stream": stream
    }, {
      headers: headers
    });
  },

  async createMessage(topic_id, message) {
    let headers = await getHeaders();
    message = message.trim();
    return axios.post(`${BASE_URL}/messages`, {
      topic_id,
      message
    }, {
      headers: headers
    });
  },

  async getMessages(topic_id) {
    let headers = await getHeaders();
    return axios.get(`${BASE_URL}/messages`, {
      headers: headers,
      params: {
        topic_id
      }
    });
  },

  async updateUserColor(color) {
    let headers = await getHeaders();
    return axios.post(`${BASE_URL}/users/color`, {
      color
    }, {
      headers: headers
    });
  }

};
/* harmony default export */ __webpack_exports__["default"] = (PogApi);

/***/ })

})
//# sourceMappingURL=contentScript.32c3d9447207fa16de9b.hot-update.js.map