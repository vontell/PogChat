webpackHotUpdate("contentScript",{

/***/ "./src/contentScript/Pogchat.js":
/*!**************************************!*\
  !*** ./src/contentScript/Pogchat.js ***!
  \**************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _PogTopicCreation__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./PogTopicCreation */ "./src/contentScript/PogTopicCreation.js");
/* harmony import */ var _PogTopicList__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./PogTopicList */ "./src/contentScript/PogTopicList.js");
/* harmony import */ var _TopicLink__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./TopicLink */ "./src/contentScript/TopicLink.js");
/* harmony import */ var _App_css__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../App.css */ "./src/App.css");
/* harmony import */ var _App_css__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_App_css__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./utils */ "./src/contentScript/utils.js");
/* harmony import */ var _api__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./api */ "./src/contentScript/api.js");
/* harmony import */ var _PogTopic__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./PogTopic */ "./src/contentScript/PogTopic.js");
/* harmony import */ var _SettingsPanel__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./SettingsPanel */ "./src/contentScript/SettingsPanel.js");
/* harmony import */ var react_spinners_PacmanLoader__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! react-spinners/PacmanLoader */ "./node_modules/react-spinners/PacmanLoader.js");
/* harmony import */ var react_spinners_PacmanLoader__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react_spinners_PacmanLoader__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _logo_png__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../logo.png */ "./src/logo.png");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__);
var _jsxFileName = "/Users/vontell/Documents/TwitchProChat/PogChatChromeExtension/src/contentScript/Pogchat.js";

/*global chrome*/














const BUTTON_CLASSES = "ScCoreButton-sc-1qn4ixc-0 ScCoreButtonPrimary-sc-1qn4ixc-1 jGqsfG ksFrFH";

function uuidv4() {
  const a = crypto.getRandomValues(new Uint16Array(8));
  let i = 0;
  return '00-0-4-1-000'.replace(/[^-]/g, s => (a[i++] + s * 0x10000 >> s).toString(16).padStart(4, '0'));
}

function Pogchat() {
  const [waitUUID, setWaitUUID] = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])(null);
  const [userInfo, setUserInfo] = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])(null);
  const [currentState, setCurrentState] = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])(null);
  const [streamInfo, setStreamInfo] = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])(null);
  const [streamTopics, setStreamTopics] = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])([]);
  const [categoryTopics, setCategoryTopics] = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])([]);
  const [popularTopics, setPopularTopics] = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])([]);
  const [participatingTopics, setParticipatingTopics] = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])([]);
  const [selectedTopic, setSelectedTopic] = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])(null);
  const [isLoading, setIsLoading] = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])(true); // Determine if already logged in

  Object(react__WEBPACK_IMPORTED_MODULE_0__["useEffect"])(() => {
    chrome.storage.sync.get("info", data => {
      setUserInfo(data.info);
    });
  }, []);
  Object(react__WEBPACK_IMPORTED_MODULE_0__["useEffect"])(() => {
    async function fetchStreamInfo() {
      setStreamInfo(await Object(_utils__WEBPACK_IMPORTED_MODULE_5__["getStreamInfo"])());
    }

    fetchStreamInfo();
  }, []); // Wait for auth if auth started

  Object(react__WEBPACK_IMPORTED_MODULE_0__["useEffect"])(() => {
    if (!waitUUID) {
      return;
    } // Poll for finishing


    function pollLogin(uuid) {
      fetch("http://localhost:8080/auth", {
        method: "POST",
        mode: "cors",
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          "accessToken": waitUUID
        })
      }).then(async data => {
        let result = await data.json();
        console.log(result);

        if (result.ready) {
          let info = {
            "access_token": result.token,
            "user": result.user
          };
          chrome.storage.sync.set({
            "info": {
              "access_token": result.token,
              "user": result.user
            }
          });
          setUserInfo(info);
          setWaitUUID(null);
          return;
        }

        setTimeout(function () {
          pollLogin(uuid);
        }, 1000);
      }).catch(err => {});
    }

    pollLogin(waitUUID);
  }, [waitUUID]);
  let downloadTopics = Object(react__WEBPACK_IMPORTED_MODULE_0__["useCallback"])(() => {
    setIsLoading(true);

    async function fetchData(streamOnly) {
      if (!userInfo || !streamInfo) {
        return;
      }

      console.log("GETTING TOPICS");
      const {
        streamId,
        category
      } = streamInfo;
      console.log(`CONTEXT: ${streamId} - ${category}`);
      _api__WEBPACK_IMPORTED_MODULE_6__["default"].getStartingTopics(streamId, category).then(data => {
        let topics = data.data;
        console.log("STARTUP TOPICS");
        console.log(topics);
        setStreamTopics(topics.streamTopics);
        setParticipatingTopics(topics.participantTopics);
        setCategoryTopics(topics.categoryTopics);
        setPopularTopics(topics.popularTopics);
      }).finally(() => {
        setIsLoading(true);
      });
    }

    fetchData();
  }, [userInfo, streamInfo]); // Fetch startup topics

  Object(react__WEBPACK_IMPORTED_MODULE_0__["useEffect"])(() => {
    downloadTopics();
  }, [userInfo, streamInfo]);
  let logout = Object(react__WEBPACK_IMPORTED_MODULE_0__["useCallback"])(() => {
    chrome.storage.sync.clear(() => {
      setUserInfo(null);
    });
  }, []);

  let onLoginClicked = () => {
    let uuid = uuidv4();
    const authLink = `https://id.twitch.tv/oauth2/authorize\n?client_id=mbiftzplnzsllgon3p5gqkbke8rkyy&redirect_uri=http://localhost:8080/auth&response_type=code&scope=user:read:email&state=${uuid}`;
    setWaitUUID(uuid);
    window.open(authLink, '_blank').focus();
  };

  let onTopicClicked = Object(react__WEBPACK_IMPORTED_MODULE_0__["useCallback"])(topic => {
    setCurrentState('viewing-topic');
    setSelectedTopic(topic);
  }, []);
  let onTopicClosed = Object(react__WEBPACK_IMPORTED_MODULE_0__["useCallback"])(() => {
    setCurrentState(null);
    setSelectedTopic(null);
  }, []);
  console.log(userInfo);
  console.log(currentState);
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("div", {
    style: {
      padding: 16,
      height: '100%'
    },
    className: "hide-scrollbar",
    children: [!userInfo && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("button", {
      style: {
        padding: 16
      },
      className: BUTTON_CLASSES,
      onClick: onLoginClicked,
      children: "Login with Twitch"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 157,
      columnNumber: 17
    }, this), userInfo && currentState == null && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("div", {
      style: {
        height: '100%'
      },
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("div", {
        style: {
          fontWeight: 'bold',
          fontSize: 14
        },
        children: ["Welcome to Pogchat, ", userInfo.user.lastKnownDisplayName, "!"]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 163,
        columnNumber: 17
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("br", {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 165,
        columnNumber: 23
      }, this), isLoading && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("div", {
        style: {
          textAlign: 'center',
          marginTop: 64
        },
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(react_spinners_PacmanLoader__WEBPACK_IMPORTED_MODULE_9___default.a, {
          color: '#5c16c5',
          loading: true
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 168,
          columnNumber: 21
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 167,
        columnNumber: 17
      }, this), streamInfo && !isLoading && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(_PogTopicList__WEBPACK_IMPORTED_MODULE_2__["default"], {
        topicList: streamTopics,
        title: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("div", {
          children: ["Recent topics in ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("span", {
            className: "Pogchat-StreamName",
            children: streamInfo.streamName
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 174,
            columnNumber: 55
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 174,
          columnNumber: 33
        }, this),
        emptyImage: "https://www.streamscheme.com/wp-content/uploads/2020/04/resident-sleeper.png",
        emptyAlt: "Resident sleeper: no topics created yet",
        emptyText: "No topics created :( add one below!",
        onTopicClicked: onTopicClicked,
        colorVariant: "PURPLE"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 172,
        columnNumber: 21
      }, this), streamInfo && !isLoading && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(_PogTopicList__WEBPACK_IMPORTED_MODULE_2__["default"], {
        topicList: categoryTopics,
        title: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("div", {
          children: ["Recent topics in ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("span", {
            className: "Pogchat-Category",
            children: streamInfo.category
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 185,
            columnNumber: 55
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 185,
          columnNumber: 33
        }, this),
        emptyImage: "https://www.pngkey.com/png/full/66-661421_jackie-chan-wtf-meme-jackie-chan.png",
        emptyAlt: "Jackie chan what: no topics created yet",
        emptyText: "No topics created :( add one below!",
        onTopicClicked: onTopicClicked,
        colorVariant: "GREEN"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 183,
        columnNumber: 21
      }, this), streamInfo && !isLoading && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(_PogTopicList__WEBPACK_IMPORTED_MODULE_2__["default"], {
        topicList: popularTopics,
        title: "Popular Topics on Twitch",
        emptyImage: "https://www.pngkey.com/png/full/66-661421_jackie-chan-wtf-meme-jackie-chan.png",
        emptyAlt: "Jackie chan what: no topics created yet",
        emptyText: "No topics created :( add one below!",
        onTopicClicked: onTopicClicked,
        colorVariant: "BLUE"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 194,
        columnNumber: 21
      }, this), streamInfo && !isLoading && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(_PogTopicList__WEBPACK_IMPORTED_MODULE_2__["default"], {
        topicList: participatingTopics,
        title: "Topics You're Participating In",
        emptyImage: _logo_png__WEBPACK_IMPORTED_MODULE_10__["default"],
        emptyAlt: "The PogChat logo",
        emptyText: "You have no topics or messages! Post a message.",
        onTopicClicked: onTopicClicked,
        colorVariant: "RED"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 205,
        columnNumber: 21
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("button", {
        style: {
          padding: 16
        },
        className: BUTTON_CLASSES,
        onClick: () => setCurrentState('create-topic'),
        children: "Create Topic"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 215,
        columnNumber: 17
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("div", {
        className: "Pogchat-Bottom-Buttons",
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("button", {
          style: {
            padding: 16,
            marginRight: '8px'
          },
          className: BUTTON_CLASSES,
          onClick: () => Object(_utils__WEBPACK_IMPORTED_MODULE_5__["typeAndSwitchToChat"])("Chat about meta, teams, and more right in Twitch chat using PogChat. Download at pogchat.gg"),
          children: "Share PogChat!"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 219,
          columnNumber: 21
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])("button", {
          style: {
            padding: 16
          },
          className: BUTTON_CLASSES,
          onClick: () => setCurrentState('settings'),
          children: "Settings"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 222,
          columnNumber: 21
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 218,
        columnNumber: 17
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 162,
      columnNumber: 13
    }, this), userInfo && currentState === 'create-topic' && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(_PogTopicCreation__WEBPACK_IMPORTED_MODULE_1__["default"], {
      closeCallback: shouldRefresh => {
        if (shouldRefresh) {
          downloadTopics();
        }

        setCurrentState(null);
      }
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 229,
      columnNumber: 17
    }, this), userInfo && currentState === 'viewing-topic' && selectedTopic && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(_PogTopic__WEBPACK_IMPORTED_MODULE_7__["default"], {
      topic: selectedTopic,
      onClose: onTopicClosed
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 237,
      columnNumber: 17
    }, this), userInfo && currentState === 'settings' && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_11__["jsxDEV"])(_SettingsPanel__WEBPACK_IMPORTED_MODULE_8__["default"], {
      closeCallback: () => setCurrentState(null),
      userInfo: userInfo,
      logoutCallback: logout
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 240,
      columnNumber: 17
    }, this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 155,
    columnNumber: 9
  }, this);
}

/* harmony default export */ __webpack_exports__["default"] = (Pogchat);

/***/ })

})
//# sourceMappingURL=contentScript.df28c4166830463cfc87.hot-update.js.map