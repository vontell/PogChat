webpackHotUpdate("contentScript",{

/***/ "./src/contentScript/PogTopic.js":
/*!***************************************!*\
  !*** ./src/contentScript/PogTopic.js ***!
  \***************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _App_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../App.css */ "./src/App.css");
/* harmony import */ var _App_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_App_css__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./utils */ "./src/contentScript/utils.js");
/* harmony import */ var _api__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./api */ "./src/contentScript/api.js");
/* harmony import */ var _fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @fortawesome/react-fontawesome */ "./node_modules/@fortawesome/react-fontawesome/index.es.js");
/* harmony import */ var _fortawesome_fontawesome_svg_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @fortawesome/fontawesome-svg-core */ "./node_modules/@fortawesome/fontawesome-svg-core/index.es.js");
/* harmony import */ var _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @fortawesome/free-solid-svg-icons */ "./node_modules/@fortawesome/free-solid-svg-icons/index.es.js");
/* harmony import */ var _PogMessage__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./PogMessage */ "./src/contentScript/PogMessage.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__);
var _jsxFileName = "/Users/vontell/Documents/TwitchProChat/PogChatChromeExtension/src/contentScript/PogTopic.js";









_fortawesome_fontawesome_svg_core__WEBPACK_IMPORTED_MODULE_5__["library"].add(_fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_6__["faArrowLeft"]);
const CHAT_REFRESH_RATE = 2500;
const BUTTON_CLASSES = "ScCoreButton-sc-1qn4ixc-0 ScCoreButtonPrimary-sc-1qn4ixc-1 jGqsfG ksFrFH";

function PogTopic({
  topic,
  onClose
}) {
  const [message, setMessage] = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])(null);
  const [messages, setMessages] = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])([]);
  const [inputHovered, setInputHovered] = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])(false);
  const [inputFocused, setInputFocused] = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])(false);
  const [isFreeScrolling, setIsFreeScrolling] = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])(false);
  const messagesContainer = Object(react__WEBPACK_IMPORTED_MODULE_0__["useRef"])();
  let createMessage = Object(react__WEBPACK_IMPORTED_MODULE_0__["useCallback"])(() => {
    _api__WEBPACK_IMPORTED_MODULE_3__["default"].createMessage(topic.id, message).then(resp => {
      setMessage(null);
      setMessages(messages.concat(resp.data));
    }).catch(() => {
      setMessage(null);
    });
  }, [message]);
  Object(react__WEBPACK_IMPORTED_MODULE_0__["useEffect"])(() => {
    _api__WEBPACK_IMPORTED_MODULE_3__["default"].getMessages(topic.id).then(resp => {
      setMessages(resp.data);
    });
  }, []); // Increment view count

  Object(react__WEBPACK_IMPORTED_MODULE_0__["useEffect"])(() => {
    _api__WEBPACK_IMPORTED_MODULE_3__["default"].viewTopic(topic.id);
  }, []);
  Object(_utils__WEBPACK_IMPORTED_MODULE_2__["useInterval"])(() => {
    _api__WEBPACK_IMPORTED_MODULE_3__["default"].getMessages(topic.id).then(resp => {
      setMessages(resp.data);
    });
  }, CHAT_REFRESH_RATE);
  let inputIsActive = inputFocused || inputHovered;
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__["jsxDEV"])("div", {
    style: {
      height: '100%',
      display: 'flex',
      flexDirection: 'column'
    },
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__["jsxDEV"])("div", {
      className: "Pogchat-Header",
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__["jsxDEV"])(_fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_4__["FontAwesomeIcon"], {
        className: "Pogchat-BackButton",
        onClick: () => onClose(),
        icon: "arrow-left"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 64,
        columnNumber: 17
      }, this), " ", topic.title]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 63,
      columnNumber: 13
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__["jsxDEV"])("div", {
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__["jsxDEV"])("span", {
        className: "Pogchat-StreamName",
        children: topic.stream
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 68,
        columnNumber: 17
      }, this), " - ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__["jsxDEV"])("span", {
        className: "Pogchat-Category",
        children: topic.category
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 68,
        columnNumber: 78
      }, this), "  (", topic.viewCount, " views)"]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 67,
      columnNumber: 13
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__["jsxDEV"])("div", {
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__["jsxDEV"])("p", {
        style: {
          fontStyle: 'italic',
          marginBottom: 16,
          cursor: 'pointer'
        },
        onClick: () => Object(_utils__WEBPACK_IMPORTED_MODULE_2__["typeAndSwitchToChat"])(`Hey, I'm chatting about "${topic.title}" in PogChat, check it out at pogchat.gg (chat about strats, metas, teams, and more right in Twitch chat)`),
        children: "Share this topic in Twitch Chat"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 72,
        columnNumber: 17
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 71,
      columnNumber: 13
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__["jsxDEV"])("div", {
      style: {
        marginBottom: 16,
        flexGrow: 1
      },
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__["jsxDEV"])("div", {
        className: "Pogchat-Message-Container",
        ref: messagesContainer,
        children: messages.map(item => {
          return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__["jsxDEV"])(_PogMessage__WEBPACK_IMPORTED_MODULE_7__["default"], {
            message: item
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 79,
            columnNumber: 32
          }, this);
        })
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 77,
        columnNumber: 17
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 76,
      columnNumber: 13
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__["jsxDEV"])("div", {
      className: "Pogchat-Input-Container",
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__["jsxDEV"])("div", {
        className: "Pogchat-Input-TextArea-Container",
        onFocus: () => setInputFocused(true),
        onBlur: () => setInputFocused(false),
        onMouseEnter: () => setInputHovered(true),
        onMouseLeave: () => setInputHovered(true),
        style: {
          border: inputIsActive ? '2px solid #afafaf' : '2px solid #dbdbdb'
        },
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__["jsxDEV"])("textarea", {
          "aria-label": "Send a message",
          autoComplete: "pog-chat",
          maxLength: "500",
          placeholder: "Send a message",
          rows: "1",
          style: {
            color: 'black',
            border: 'none',
            overflow: 'auto',
            outline: 'none',
            resize: 'none',
            backgroundColor: 'transparent',
            padding: 4,
            height: '100%',
            width: '100%',
            fontFamily: 'inherit'
          },
          value: message,
          onChange: ev => {
            setMessage(ev.target.value);
          }
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 91,
          columnNumber: 21
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 85,
        columnNumber: 17
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__["jsxDEV"])("div", {
        className: "Pogchat-Button-Container",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__["jsxDEV"])("button", {
          style: {
            padding: 16,
            float: 'right',
            height: "100%"
          },
          className: BUTTON_CLASSES,
          onClick: createMessage,
          children: "Send"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 112,
          columnNumber: 21
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 111,
        columnNumber: 17
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 84,
      columnNumber: 13
    }, this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 61,
    columnNumber: 9
  }, this);
}

/* harmony default export */ __webpack_exports__["default"] = (PogTopic);

/***/ })

})
//# sourceMappingURL=contentScript.d080e2ceab092f6917e7.hot-update.js.map