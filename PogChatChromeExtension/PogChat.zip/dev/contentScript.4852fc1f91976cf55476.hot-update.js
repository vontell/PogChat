webpackHotUpdate("contentScript",{

/***/ "./src/contentScript/index.js":
/*!************************************!*\
  !*** ./src/contentScript/index.js ***!
  \************************************/
/*! exports provided: waitToAttachPogchat, attachButtonSwitchers, mountReactPogger, attachLogout */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "waitToAttachPogchat", function() { return waitToAttachPogchat; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "attachButtonSwitchers", function() { return attachButtonSwitchers; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "mountReactPogger", function() { return mountReactPogger; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "attachLogout", function() { return attachLogout; });
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react-dom */ "./node_modules/react-dom/index.js");
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_dom__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _Pogchat__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./Pogchat */ "./src/contentScript/Pogchat.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__);
var _jsxFileName = "/Users/vontell/Documents/TwitchProChat/PogChatChromeExtension/src/contentScript/index.js";
// If your extension doesn't need a content script, just leave this file empty
// This is an example of a script that will run on every page. This can alter pages
// Don't forget to change `matches` in manifest.json if you want to only change specific webpages




const CHAT_CONTAINER_SEL = "section[data-test-selector='chat-room-component-layout']";
const CHAT_HEADER_SEL = "h4[data-test-selector='chat-room-header-label']";
const BUTTON_CLASSES = "ScCoreButton-sc-1qn4ixc-0 ScCoreButtonPrimary-sc-1qn4ixc-1 jGqsfG ksFrFH";
waitToAttachPogchat(); // Waits until the Twitch page loads, and then attaches the PogChat

function waitToAttachPogchat() {
  let chatContainer = document.body.querySelector(CHAT_CONTAINER_SEL);
  console.log(chatContainer);

  if (!chatContainer) {
    setTimeout(waitToAttachPogchat, 1000);
  } else {
    attachButtonSwitchers();
    mountReactPogger();
  }
}
function attachButtonSwitchers() {
  // First, we grab the "STREAM CHAT" header
  let chatHeader = document.body.querySelector(CHAT_HEADER_SEL);
  let chatContainer = document.body.querySelector(CHAT_CONTAINER_SEL);
  console.log(chatHeader);
  const originalChatDisplay = chatContainer.style.display; // Create the container for the pogchat, but hide it

  const pogChatContainer = document.createElement("div");
  pogChatContainer.id = 'pogchat-container';
  chatContainer.parentNode.appendChild(pogChatContainer);
  const originalPogChatDisplay = pogChatContainer.style.display;
  pogChatContainer.style.setProperty('display', 'none', 'important');
  pogChatContainer.style.setProperty('height', '100%');
  pogChatContainer.id = "pogchat-container"; // Construct the normal chat button

  const chatButton = document.createElement("button");
  chatButton.className = BUTTON_CLASSES;
  chatButton.innerHTML = "Twitch Chat";
  chatButton.style.padding = '16px'; // Construct the Pog Chat button

  const pogButton = document.createElement("button");
  pogButton.className = BUTTON_CLASSES;
  pogButton.innerHTML = "PogChat";
  pogButton.style.padding = '16px';
  pogButton.style.backgroundColor = '#ED2938';
  pogButton.style.marginLeft = '12px';

  pogButton.onmouseenter = () => {
    pogButton.style.backgroundColor = '#c22a37';
  };

  pogButton.onmouseleave = () => {
    pogButton.style.backgroundColor = '#ED2938';
  };

  pogButton.onclick = () => {
    console.log("PRO CHAT CLICKED");
    chatContainer.style.setProperty('display', 'none', 'important');
    pogChatContainer.style.display = originalPogChatDisplay;
  };

  chatButton.onclick = () => {
    console.log("NORMAL CHAT CLICKED");
    pogChatContainer.style.setProperty('display', 'none', 'important');
    chatContainer.style.display = originalChatDisplay;
  }; // Construct the Div to hold the two


  const buttonContainer = document.createElement("div");
  buttonContainer.style.display = 'inline';
  buttonContainer.appendChild(chatButton);
  buttonContainer.appendChild(pogButton);
  chatHeader.parentNode.replaceChild(buttonContainer, chatHeader);
}
function mountReactPogger() {
  react_dom__WEBPACK_IMPORTED_MODULE_0___default.a.render( /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__["jsxDEV"])(react__WEBPACK_IMPORTED_MODULE_1___default.a.StrictMode, {
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__["jsxDEV"])(_Pogchat__WEBPACK_IMPORTED_MODULE_2__["default"], {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 87,
      columnNumber: 9
    }, this)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 86,
    columnNumber: 7
  }, this), document.getElementById("pogchat-container"));
}
function attachLogout() {}

/***/ })

})
//# sourceMappingURL=contentScript.4852fc1f91976cf55476.hot-update.js.map