webpackHotUpdate("contentScript",{

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/postcss-loader/src/index.js?!./src/App.css":
/*!************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--5-oneOf-4-1!./node_modules/postcss-loader/src??postcss!./src/App.css ***!
  \************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__);
// Imports

var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default()(true);
// Module
___CSS_LOADER_EXPORT___.push([module.i, ".App {\n  text-align: center;\n}\n\n.App-logo {\n  height: 40vmin;\n  pointer-events: none;\n}\n\n@media (prefers-reduced-motion: no-preference) {\n  .App-logo {\n    animation: App-logo-spin infinite 20s linear;\n  }\n}\n\n.App-header {\n  background-color: #282c34;\n  min-height: 150px;\n  min-width: 150px;\n  padding: 30px;\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  justify-content: center;\n  font-size: calc(10px + 2vmin);\n  color: white;\n}\n\n.App-link {\n  color: #61dafb;\n}\n\n.Pogchat-StreamName {\n  color: #9307cc;\n}\n\n.Pogchat-Category {\n  color: #ff5300\n}\n\n.Pogchat-Header {\n  font-weight: bold;\n  font-size: 20px;\n  margin-bottom: 12px;\n}\n\n.Pogchat-BackButton {\n  cursor: pointer;\n  margin-right: 8px;\n}\n\n.Pogchat-TextInput {\n  background-color: lightgray;\n  border: none;\n  border-radius: 4px;\n  outline: none;\n  padding: 8px;\n}\n\n.Pogchat-TextInput-Label {\n  font-weight: 600;\n  font-size: 14px;\n}\n\n.Pogchat-TopicLink-Container {\n  white-space: nowrap;\n  overflow-x: auto;\n  margin-bottom: 16px;\n}\n\n.Pogchat-TopicLink-Header {\n  font-weight: bold;\n  font-size: 13px;\n  margin-bottom: 4px;\n}\n\n.Pogchat-TopicLink {\n  width: 184px;\n  color: white;\n  border-radius: 0.4rem;\n  padding: 8px;\n  font-weight: 600;\n  display: inline-flex;\n  margin-right: 8px;\n  cursor: pointer;\n}\n\n.Pogchat-TopicLink-Title {\n  height: 38px;\n  overflow-y: hidden;\n}\n\n.Pogchat-TopicLink-Author {\n  font-style: italic;\n  color: white;\n  font-size: 10px;\n  font-weight: 100;\n  display: inline;\n  float: left;\n}\n\n.Pogchat-TopicLink-Date {\n  font-style: italic;\n  color: white;\n  font-size: 10px;\n  font-weight: 100;\n  display: inline;\n  float: right;\n}\n\n.Pogchat-Message-Container {\n  height: calc(100% - 200px);\n  overflow-y: scroll;\n  margin-bottom: 16px;\n}\n\n.Pogchat-Message {\n  margin-bottom: 8px;\n  word-break: break-word;\n}\n\n.Pogchat-Empty-Topic {\n  margin-top: 12px;\n  text-align: center;\n}\n\n.Pogchat-Bottom-Buttons {\n  bottom: 12px;\n  right: 12px;\n  display: inline-flex;\n  position: absolute;\n}\n\n.Pogchat-Input-Container {\n\n}\n\n.Pogchat-Input-TextArea-Container {\n  display: inline;\n  background-color: #dbdbdb;\n  border-radius: 6px;\n  transition: border 0.2s ease-in;\n}\n\n.Pogchat-Button-Container {\n\n}\n\n/* Hide scrollbar for Chrome, Safari and Opera */\n.hide-scrollbar::-webkit-scrollbar {\n  display: none;\n}\n\n/* Hide scrollbar for IE, Edge and Firefox */\n.hide-scrollbar {\n  -ms-overflow-style: none;  /* IE and Edge */\n  scrollbar-width: none;  /* Firefox */\n}\n\n@keyframes App-logo-spin {\n  from {\n    transform: rotate(0deg);\n  }\n  to {\n    transform: rotate(360deg);\n  }\n}\n", "",{"version":3,"sources":["webpack://src/App.css"],"names":[],"mappings":"AAAA;EACE,kBAAkB;AACpB;;AAEA;EACE,cAAc;EACd,oBAAoB;AACtB;;AAEA;EACE;IACE,4CAA4C;EAC9C;AACF;;AAEA;EACE,yBAAyB;EACzB,iBAAiB;EACjB,gBAAgB;EAChB,aAAa;EACb,aAAa;EACb,sBAAsB;EACtB,mBAAmB;EACnB,uBAAuB;EACvB,6BAA6B;EAC7B,YAAY;AACd;;AAEA;EACE,cAAc;AAChB;;AAEA;EACE,cAAc;AAChB;;AAEA;EACE;AACF;;AAEA;EACE,iBAAiB;EACjB,eAAe;EACf,mBAAmB;AACrB;;AAEA;EACE,eAAe;EACf,iBAAiB;AACnB;;AAEA;EACE,2BAA2B;EAC3B,YAAY;EACZ,kBAAkB;EAClB,aAAa;EACb,YAAY;AACd;;AAEA;EACE,gBAAgB;EAChB,eAAe;AACjB;;AAEA;EACE,mBAAmB;EACnB,gBAAgB;EAChB,mBAAmB;AACrB;;AAEA;EACE,iBAAiB;EACjB,eAAe;EACf,kBAAkB;AACpB;;AAEA;EACE,YAAY;EACZ,YAAY;EACZ,qBAAqB;EACrB,YAAY;EACZ,gBAAgB;EAChB,oBAAoB;EACpB,iBAAiB;EACjB,eAAe;AACjB;;AAEA;EACE,YAAY;EACZ,kBAAkB;AACpB;;AAEA;EACE,kBAAkB;EAClB,YAAY;EACZ,eAAe;EACf,gBAAgB;EAChB,eAAe;EACf,WAAW;AACb;;AAEA;EACE,kBAAkB;EAClB,YAAY;EACZ,eAAe;EACf,gBAAgB;EAChB,eAAe;EACf,YAAY;AACd;;AAEA;EACE,0BAA0B;EAC1B,kBAAkB;EAClB,mBAAmB;AACrB;;AAEA;EACE,kBAAkB;EAClB,sBAAsB;AACxB;;AAEA;EACE,gBAAgB;EAChB,kBAAkB;AACpB;;AAEA;EACE,YAAY;EACZ,WAAW;EACX,oBAAoB;EACpB,kBAAkB;AACpB;;AAEA;;AAEA;;AAEA;EACE,eAAe;EACf,yBAAyB;EACzB,kBAAkB;EAClB,+BAA+B;AACjC;;AAEA;;AAEA;;AAEA,gDAAgD;AAChD;EACE,aAAa;AACf;;AAEA,4CAA4C;AAC5C;EACE,wBAAwB,GAAG,gBAAgB;EAC3C,qBAAqB,GAAG,YAAY;AACtC;;AAEA;EACE;IACE,uBAAuB;EACzB;EACA;IACE,yBAAyB;EAC3B;AACF","sourcesContent":[".App {\n  text-align: center;\n}\n\n.App-logo {\n  height: 40vmin;\n  pointer-events: none;\n}\n\n@media (prefers-reduced-motion: no-preference) {\n  .App-logo {\n    animation: App-logo-spin infinite 20s linear;\n  }\n}\n\n.App-header {\n  background-color: #282c34;\n  min-height: 150px;\n  min-width: 150px;\n  padding: 30px;\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  justify-content: center;\n  font-size: calc(10px + 2vmin);\n  color: white;\n}\n\n.App-link {\n  color: #61dafb;\n}\n\n.Pogchat-StreamName {\n  color: #9307cc;\n}\n\n.Pogchat-Category {\n  color: #ff5300\n}\n\n.Pogchat-Header {\n  font-weight: bold;\n  font-size: 20px;\n  margin-bottom: 12px;\n}\n\n.Pogchat-BackButton {\n  cursor: pointer;\n  margin-right: 8px;\n}\n\n.Pogchat-TextInput {\n  background-color: lightgray;\n  border: none;\n  border-radius: 4px;\n  outline: none;\n  padding: 8px;\n}\n\n.Pogchat-TextInput-Label {\n  font-weight: 600;\n  font-size: 14px;\n}\n\n.Pogchat-TopicLink-Container {\n  white-space: nowrap;\n  overflow-x: auto;\n  margin-bottom: 16px;\n}\n\n.Pogchat-TopicLink-Header {\n  font-weight: bold;\n  font-size: 13px;\n  margin-bottom: 4px;\n}\n\n.Pogchat-TopicLink {\n  width: 184px;\n  color: white;\n  border-radius: 0.4rem;\n  padding: 8px;\n  font-weight: 600;\n  display: inline-flex;\n  margin-right: 8px;\n  cursor: pointer;\n}\n\n.Pogchat-TopicLink-Title {\n  height: 38px;\n  overflow-y: hidden;\n}\n\n.Pogchat-TopicLink-Author {\n  font-style: italic;\n  color: white;\n  font-size: 10px;\n  font-weight: 100;\n  display: inline;\n  float: left;\n}\n\n.Pogchat-TopicLink-Date {\n  font-style: italic;\n  color: white;\n  font-size: 10px;\n  font-weight: 100;\n  display: inline;\n  float: right;\n}\n\n.Pogchat-Message-Container {\n  height: calc(100% - 200px);\n  overflow-y: scroll;\n  margin-bottom: 16px;\n}\n\n.Pogchat-Message {\n  margin-bottom: 8px;\n  word-break: break-word;\n}\n\n.Pogchat-Empty-Topic {\n  margin-top: 12px;\n  text-align: center;\n}\n\n.Pogchat-Bottom-Buttons {\n  bottom: 12px;\n  right: 12px;\n  display: inline-flex;\n  position: absolute;\n}\n\n.Pogchat-Input-Container {\n\n}\n\n.Pogchat-Input-TextArea-Container {\n  display: inline;\n  background-color: #dbdbdb;\n  border-radius: 6px;\n  transition: border 0.2s ease-in;\n}\n\n.Pogchat-Button-Container {\n\n}\n\n/* Hide scrollbar for Chrome, Safari and Opera */\n.hide-scrollbar::-webkit-scrollbar {\n  display: none;\n}\n\n/* Hide scrollbar for IE, Edge and Firefox */\n.hide-scrollbar {\n  -ms-overflow-style: none;  /* IE and Edge */\n  scrollbar-width: none;  /* Firefox */\n}\n\n@keyframes App-logo-spin {\n  from {\n    transform: rotate(0deg);\n  }\n  to {\n    transform: rotate(360deg);\n  }\n}\n"],"sourceRoot":""}]);
// Exports
/* harmony default export */ __webpack_exports__["default"] = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./src/contentScript/PogTopic.js":
/*!***************************************!*\
  !*** ./src/contentScript/PogTopic.js ***!
  \***************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _App_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../App.css */ "./src/App.css");
/* harmony import */ var _App_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_App_css__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./utils */ "./src/contentScript/utils.js");
/* harmony import */ var _api__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./api */ "./src/contentScript/api.js");
/* harmony import */ var _fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @fortawesome/react-fontawesome */ "./node_modules/@fortawesome/react-fontawesome/index.es.js");
/* harmony import */ var _fortawesome_fontawesome_svg_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @fortawesome/fontawesome-svg-core */ "./node_modules/@fortawesome/fontawesome-svg-core/index.es.js");
/* harmony import */ var _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @fortawesome/free-solid-svg-icons */ "./node_modules/@fortawesome/free-solid-svg-icons/index.es.js");
/* harmony import */ var _PogMessage__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./PogMessage */ "./src/contentScript/PogMessage.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__);
var _jsxFileName = "/Users/vontell/Documents/TwitchProChat/PogChatChromeExtension/src/contentScript/PogTopic.js";









_fortawesome_fontawesome_svg_core__WEBPACK_IMPORTED_MODULE_5__["library"].add(_fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_6__["faArrowLeft"]);
const CHAT_REFRESH_RATE = 2500;
const BUTTON_CLASSES = "ScCoreButton-sc-1qn4ixc-0 ScCoreButtonPrimary-sc-1qn4ixc-1 jGqsfG ksFrFH";

function PogTopic({
  topic,
  onClose
}) {
  const [message, setMessage] = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])(null);
  const [messages, setMessages] = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])([]);
  const [inputHovered, setInputHovered] = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])(false);
  const [inputFocused, setInputFocused] = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])(false);
  let createMessage = Object(react__WEBPACK_IMPORTED_MODULE_0__["useCallback"])(() => {
    _api__WEBPACK_IMPORTED_MODULE_3__["default"].createMessage(topic.id, message).then(resp => {
      setMessage(null);
      setMessages(messages.concat(resp.data));
    }).catch(() => {
      setMessage(null);
    });
  }, [message]);
  Object(react__WEBPACK_IMPORTED_MODULE_0__["useEffect"])(() => {
    _api__WEBPACK_IMPORTED_MODULE_3__["default"].getMessages(topic.id).then(resp => {
      setMessages(resp.data);
    });
  }, []); // Increment view count

  Object(react__WEBPACK_IMPORTED_MODULE_0__["useEffect"])(() => {
    _api__WEBPACK_IMPORTED_MODULE_3__["default"].viewTopic(topic.id);
  }, []);
  Object(_utils__WEBPACK_IMPORTED_MODULE_2__["useInterval"])(() => {
    _api__WEBPACK_IMPORTED_MODULE_3__["default"].getMessages(topic.id).then(resp => {
      setMessages(resp.data);
    });
  }, CHAT_REFRESH_RATE);
  let inputIsActive = inputFocused || inputHovered;
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__["jsxDEV"])("div", {
    style: {
      height: '100%'
    },
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__["jsxDEV"])("div", {
      className: "Pogchat-Header",
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__["jsxDEV"])(_fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_4__["FontAwesomeIcon"], {
        className: "Pogchat-BackButton",
        onClick: () => onClose(),
        icon: "arrow-left"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 61,
        columnNumber: 17
      }, this), " ", topic.title]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 60,
      columnNumber: 13
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__["jsxDEV"])("div", {
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__["jsxDEV"])("span", {
        className: "Pogchat-StreamName",
        children: topic.stream
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 65,
        columnNumber: 17
      }, this), " - ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__["jsxDEV"])("span", {
        className: "Pogchat-Category",
        children: topic.category
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 65,
        columnNumber: 78
      }, this), "  (", topic.viewCount, " views)"]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 64,
      columnNumber: 13
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__["jsxDEV"])("div", {
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__["jsxDEV"])("p", {
        style: {
          fontStyle: 'italic',
          marginBottom: 16,
          cursor: 'pointer'
        },
        onClick: () => Object(_utils__WEBPACK_IMPORTED_MODULE_2__["typeAndSwitchToChat"])(`Hey, I'm chatting about "${topic.title}" in PogChat, check it out at pogchat.gg (chat about strats, metas, teams, and more right in Twitch chat)`),
        children: "Share this topic in Twitch Chat"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 69,
        columnNumber: 17
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 68,
      columnNumber: 13
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__["jsxDEV"])("div", {
      className: "Pogchat-Message-Container",
      children: messages.map(item => {
        return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__["jsxDEV"])(_PogMessage__WEBPACK_IMPORTED_MODULE_7__["default"], {
          message: item
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 75,
          columnNumber: 28
        }, this);
      })
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 73,
      columnNumber: 13
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__["jsxDEV"])("div", {
      className: "Pogchat-Input-Container",
      style: {
        border: inputIsActive ? '2px solid #afafaf' : '2px solid #dbdbdb'
      },
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__["jsxDEV"])("div", {
        className: "Pogchat-Input-TextArea-Container",
        onFocus: () => setInputFocused(true),
        onBlur: () => setInputFocused(false),
        onMouseEnter: () => setInputHovered(true),
        onMouseLeave: () => setInputHovered(true),
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__["jsxDEV"])("textarea", {
          "aria-label": "Send a message",
          autoComplete: "pog-chat",
          maxLength: "500",
          placeholder: "Send a message",
          rows: "1",
          style: {
            color: 'black',
            border: 'none',
            overflow: 'auto',
            outline: 'none',
            resize: 'none',
            backgroundColor: 'transparent',
            padding: 4
          },
          value: message,
          onChange: ev => {
            setMessage(ev.target.value);
          }
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 85,
          columnNumber: 21
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 80,
        columnNumber: 17
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__["jsxDEV"])("div", {
        className: "Pogchat-Button-Container",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__["jsxDEV"])("button", {
          style: {
            padding: 16,
            float: 'right',
            marginRight: '16px'
          },
          className: BUTTON_CLASSES,
          onClick: createMessage,
          children: "Send"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 103,
          columnNumber: 21
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 102,
        columnNumber: 17
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 79,
      columnNumber: 13
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__["jsxDEV"])("div", {
      style: {}
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 109,
      columnNumber: 13
    }, this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 58,
    columnNumber: 9
  }, this);
}

/* harmony default export */ __webpack_exports__["default"] = (PogTopic);

/***/ })

})
//# sourceMappingURL=contentScript.8ab5d67fccea4898d2e2.hot-update.js.map